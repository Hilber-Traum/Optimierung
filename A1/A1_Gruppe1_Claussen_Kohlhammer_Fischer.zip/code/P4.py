## Hier werden sämtliche in dieser Datei benötigten Pakete und Module geladen
import numpy as np
import matplotlib.pyplot as plt


## TODO: Aufgabenteil 4a. Dimensionsumformungen eines Vektors
print('### 4a ###')
# BEGIN SOLUTION
...
# END SOLUTION


## TODO: Aufgabenteil 4b. Logische Indizierung bei Vektoren
print('\n### 4b ###')
# BEGIN SOLUTION
...
# END SOLUTION


## TODO: Aufgabenteil 4c. Einheitsmatrix erzeugen
print('\n### 4c ###')
# BEGIN SOLUTION
...
# END SOLUTION


## TODO: Aufgabenteil 4d. Hauptminor der Einheitsmatrix visualisieren
# BEGIN SOLUTION
...
# END SOLUTION


## TODO: Aufgabenteil 4e. exp und log von ndarrays
print('\n### 4e ###')
A = np.array([[1, 0, 3, 4], [3, 1, 1, 0], [0, -1, 2, 3], [1, 0, 0, -1]])
B = np.array([[8, 10, -13, 6], [5, 5.5, -1, -4], [4, 6.5, -11, 7], [0, 0, 2, -2]])

# BEGIN SOLUTION
...
# END SOLUTION


## TODO: Aufgabenteil 4f. Zeile und Spalte ausgeben
print('\n### 4f ###')
# BEGIN SOLUTION
...
# END SOLUTION


## TODO: Aufgabenteil 4g. LGS lösen
print('\n### 4g ###')
# BEGIN SOLUTION
...
# END SOLUTION
